#!/system/bin/sh

#sesh
#bones

echo "we're the best"

setseshConfig() {
echo "schedutil" > /sys/devices/system/cpu/cpufreq/policy0/scaling_governor 
echo "schedutil" > /sys/devices/system/cpu/cpufreq/policy4/scaling_governor 
echo "10" > /sys/class/thermal/thermal_message/sconfig
echo "mem" > /sys/power/autosleep
echo "Y" > /sys/module/lpm_levels/parameters/cluster_use_deepest_state 
echo "710000000" > /sys/class/kgsl/kgsl-3d0/max_gpuclk 
echo "NO_FBT_STRICT_ORDER" > /sys/kernel/debug/sched_features
echo "0" > /proc/sys/kernel/sched_walt_rotate_big_tasks
echo "Y" > /sys/module/bluetooth/parameters/disable_ertm
echo "Y" > /sys/module/bluetooth/parameters/disable_esco

dt=`date '+%d/%m/%Y %H:%M:%S'`
echo "$dt Initial kernel settings applied" >> /storage/emulated/0/TKManagerV4/log.txt
}
setBalancedConfig() {
sleep $bootdelay
balanced
}
setBatteryConfig() {
sleep $bootdelay
battery
}
setPerformanceConfig() {
sleep $bootdelay
performance
}
setGamingConfig() {
sleep $bootdelay
gaming
}
RunConfig() {
config="/storage/emulated/0/TKManagerV4/seshconfig.txt"
until [  $COUNTER == 69 ]; do
cfsync=$(grep "tk.config.Fsync" "$config" | cut -d '=' -f2)
cfsync=$(echo "$cfsync" | awk -v FPAT="[0-9]+" '{print $NF}')
cctherm=$(grep "tk.config.ctherm" "$config" | cut -d '=' -f2)
cctherm=$(echo "$cctherm" | awk -v FPAT="[0-9]+" '{print $NF}')
cthermstate=$(cat /sys/module/smb_lib/parameters/skip_thermal)
fsyncstate=$(cat /sys/module/sync/parameters/fsync_enabled)
if [ "$cfsync" == N ];
then
if [ "$fsyncstate" == Y ]; then
echo "N" > /sys/module/sync/parameters/fsync_enabled
dt=`date '+%d/%m/%Y %H:%M:%S'`
echo "$dt Fsync disabled" >> /storage/emulated/0/TKManagerV4/log.txt
fi
else
if [ "$fsyncstate" == N ]; then
echo "Y" > /sys/module/sync/parameters/fsync_enabled
dt=`date '+%d/%m/%Y %H:%M:%S'`
echo "$dt Fsync enabled" >> /storage/emulated/0/TKManagerV4/log.txt
fi
fi
if [ "$cctherm" == 0 ]; then
if [ "$cthermstate" == N ]; then
echo "Y" > /sys/module/smb_lib/parameters/skip_thermal
dt=`date '+%d/%m/%Y %H:%M:%S'`
echo "$dt Charging throttle disabled" >> /storage/emulated/0/TKManagerV4/log.txt
fi
else
if [ "$cthermstate" == Y ]; then
echo "N" > /sys/module/smb_lib/parameters/skip_thermal
dt=`date '+%d/%m/%Y %H:%M:%S'`
echo "$dt Charging throttle enabled" >> /storage/emulated/0/TKManagerV4/log.txt
fi
fi
sleep 15
done
}
ProfileHandler() {
#sesh
until [  $COUNTER == 69 ]; do
spprop="$(getprop persist.spectrum.profile)"
if [ "$spprop" == 0 ]; then
balanced
setprop persist.spectrum.profile 4
fi
if [ "$spprop" == 1 ]; then
performance
setprop persist.spectrum.profile 4
fi
if [ "$spprop" == 2 ]; then
battery
setprop persist.spectrum.profile 4
fi
if [ "$spprop" == 3 ]; then
gaming
setprop persist.spectrum.profile 4
fi
sleep 5
done
}
CPUSet() {
sleep 280
setcpu
}
ChargeLimiter() {
#sesh
until [  $COUNTER == 69 ]; do
bc=`cat /sys/class/power_supply/battery/capacity`
is=`cat /sys/class/power_supply/battery/input_suspend`
mc=`cat /storage/emulated/0/TKManagerV4/charging/max_charge.txt`
if [ "$mc" -ge 40 ]; then 
let "re=mc-2"
else
echo "101" > /storage/emulated/0/TKManagerV4/charging/max_charge.txt
mc=`cat /storage/emulated/0/TKManagerV4/charging/max_charge.txt`
let "re=mc-2"
dt=`date '+%d/%m/%Y %H:%M:%S'`
echo "$dt Maxcharge value invalid. Set back to 101%" >> /storage/emulated/0/TKManagerV4/log.txt
fi
if [ "$bc" -le $re ] && [ "$is" == 1 ]; 
then
echo "0" > /sys/class/power_supply/battery/input_suspend
dt=`date '+%d/%m/%Y %H:%M:%S'`
echo "$dt Charging enabled" >> /storage/emulated/0/TKManagerV4/log.txt
fi
if [ "$bc" -ge $mc ] && [ "$is" == 0 ]; 
then
echo "1" > /sys/class/power_supply/battery/input_suspend
dt=`date '+%d/%m/%Y %H:%M:%S'`
echo "$dt Charge limited at $mc %" >> /storage/emulated/0/TKManagerV4/log.txt
fi
sleep 20
done
}
PowerSaver() {
#sesh
sleep 45
echo "$dt Auto power saver running" >> /storage/emulated/0/TKManagerV4/log.txt
until [  $COUNTER == 69 ]; do
bc=`cat /sys/class/power_supply/battery/capacity`
lpm_threshold=`cat /storage/emulated/0/TKManagerV4/powersaver/low_powersave_trigger.txt`
if [ "$bc" -le $lpm_threshold ] && [ "$psactive" == 0 ]; then
prevprof=$(cat /storage/emulated/0/TKManagerV4/dev/profile.txt)     
battery
dt=`date '+%d/%m/%Y %H:%M:%S'`
echo "$dt Low power saver activated" >> /storage/emulated/0/TKManagerV4/log.txt
psactive=1
fi
if [ "$bc" -gt $lpm_threshold ] && [ "$psactive" == 1 ]; then
if [ "$prevprof" == 1 ]; then
performance
elif [ "$prevprof" == 2 ]; then
battery
elif [ "$prevprof" == 3 ]; then
gaming
else
balanced
fi
dt=`date '+%d/%m/%Y %H:%M:%S'`
echo "$dt Low power saver deactivated" >> /storage/emulated/0/TKManagerV4/log.txt
psactive=0
fi
sleep 40
done
}
InitEngine() {
COUNTER=420
if [ -f /storage/emulated/0/TKManagerV4/seshconfig.txt ]; then
RunConfig &
fi
ChargeLimiter &
ps_enable=`cat /storage/emulated/0/TKManagerV4/powersaver/low_powersave_toggle.txt`
if [ "$ps_enable" == 1 ]; then
psactive=0
PowerSaver &
fi
ProfileHandler &
CPUSet &
}
if ! grep -q seshKernel /proc/version; then
rm -rf /data/adb/modules/seshkernel
rm -rf /data/seshconfig
exit 0
else
setprop spectrum.support 1
setprop persist.spectrum.kernel sesh
setprop touch.pressure.scale 0.001
setprop debug.composition.type c2d
setprop TapInterval 1ms
setprop TapSlop 1px
while [ "$(getprop sys.boot_completed)" != 1 ]; do
	sleep 2
done
if [ -f /storage/emulated/0/TKManagerV4/sesconfig.txt ]; then
config="/storage/emulated/0/TKManagerV4/seshconfig.txt"
bootdelay=$(grep "tk.config.delay" "$config" | cut -d '=' -f2)
bootdelay=$(echo "$bootdelay" | awk -v FPAT="[0-9]+" '{print $NF}')
if ! [ "$bootdelay" -ge 0 -a "$bootdelay" -le 90 ]; then 
bootdelay=50
fi
else
bootdelay=50
fi
dt=`date '+%d/%m/%Y %H:%M:%S'`
echo "$bootdelay second delay started" > /storage/emulated/0/TKManagerV4/log.txt
mount -o remount, rw /system;
chmod +x /system/bin/trim
chmod +x /system/bin/setcpu
chmod +x /system/bin/unthermal
chmod +x /system/bin/rethermal
chmod +x /system/bin/battery
chmod +x /system/bin/performance
chmod +x /system/bin/balanced
chmod +x /system/bin/gaming
mount -o remount, ro /system;
rm /data/adb/modules/seshkernel/disable
mkdir -p /storage/emulated/0/TKManagerV4/{dev,powersaver,charging}
if [ ! -f /storage/emulated/0/TKManagerV4/charging/max_charge.txt ]; then
echo "101" > /storage/emulated/0/TKManagerV4/charging/max_charge.txt
fi
if [ ! -f /storage/emulated/0/TKManagerV4/powersaver/low_powersave_toggle.txt ]; then
echo "0" > /storage/emulated/0/TKManagerV4/powersaver/low_powersave_toggle.txt
fi
if [ ! -f /storage/emulated/0/TKManagerV4/powersaver/low_powersave_trigger.txt ]; then
echo "25" > /storage/emulated/0/TKManagerV4/powersaver/low_powersave_trigger.txt
fi
echo "maxcharge.txt" > /storage/emulated/0/TKManagerV4/charging/instructions.txt
echo "Charging will stop when battery percentage is equal to the value in this file." >> /storage/emulated/0/TKManagerV4/charging/instructions.txt
echo "Set the value to 101 so charging isn't stopped" >> /storage/emulated/0/TKManagerV4/charging/instructions.txt
echo "low_powersave_toggle.txt" > /storage/emulated/0/TKManagerV4/powersaver/instructions.txt
echo "Set the value in this file to 1 to enable." >> /storage/emulated/0/TKManagerV4/powersaver/instructions.txt
echo "" >> /storage/emulated/0/TKManagerV4/powersaver/instructions.txt
echo "low_powersave_trigger.txt" >> /storage/emulated/0/TKManagerV4/powersaver/instructions.txt
echo "CPU and GPU will be underclocked when battery percentage is equal/below the value in the file." >> /storage/emulated/0/TKManagerV4/powersaver/instructions.txt
rm -rf /storage/emulated/0/TKManager

devicename="$(settings get global device_name)"
dt=`date '+%d/%m/%Y %H:%M:%S'`
echo "$devicename" >> /storage/emulated/0/TKManagerV4/log.txt
setseshConfig &
device="$(getprop ro.build.product)"
kversion=`cat /proc/version`
echo "$device" > /storage/emulated/0/TKManagerV4/dev/device.txt
echo "$kversion" > /storage/emulated/0/TKManagerV4/dev/kversion.txt
if [ ! -f /storage/emulated/0/TKManagerV4/seshconfig.txt ]; then
echo "# sesh Kernel configuration file V4" >> /storage/emulated/0/TKManagerV4/seshconfig.txt
echo "# Change the values to suit your needs" >> /storage/emulated/0/TKManagerV4/seshconfig.txt
echo " " >> /storage/emulated/0/TKManagerV4/seshconfig.txt
echo "# Set an apply on boot delay:" >> /storage/emulated/0/TKManagerV4/seshconfig.txt
echo "# Values 0 - 90 accepted (recommended 55 seconds)" >> /storage/emulated/0/TKManagerV4/seshconfig.txt
echo " " >> /storage/emulated/0/TKManagerV4/seshconfig.txt
echo "tk.config.delay 55" >> /storage/emulated/0/TKManagerV4/seshconfig.txt
echo " " >> /storage/emulated/0/TKManagerV4/seshconfig.txt
echo "# Select a performance profile:" >> /storage/emulated/0/TKManagerV4/seshconfig.txt
echo "# 0 - Balanced (Default)" >> /storage/emulated/0/TKManagerV4/seshconfig.txt
echo "# 1 - Performance (Tuned for top performance)" >> /storage/emulated/0/TKManagerV4/seshconfig.txt
echo '# 2 - Battery (Underclocks CPU and GPU)' >> /storage/emulated/0/TKManagerV4/seshconfig.txt
echo "# 3 - Gaming (Throttles less for sustained performance)" >> /storage/emulated/0/TKManagerV4/seshconfig.txt
echo " " >> /storage/emulated/0/TKManagerV4/seshconfig.txt
echo "tk.config.prof 0" >> /storage/emulated/0/TKManagerV4/seshconfig.txt
echo " " >> /storage/emulated/0/TKManagerV4/seshconfig.txt
echo "# Set vibration strength." >> /storage/emulated/0/TKManagerV4/seshconfig.txt
echo "# Values between 0-100 accepted." >> /storage/emulated/0/TKManagerV4/seshconfig.txt
echo "# Vibration strength for notifications:" >> /storage/emulated/0/TKManagerV4/seshconfig.txt
echo " " >> /storage/emulated/0/TKManagerV4/seshconfig.txt
echo "tk.config.vibnotif 100" >> /storage/emulated/0/TKManagerV4/seshconfig.txt
echo " " >> /storage/emulated/0/TKManagerV4/seshconfig.txt
echo "# Vibration strength for calls:" >> /storage/emulated/0/TKManagerV4/seshconfig.txt
echo " " >> /storage/emulated/0/TKManagerV4/seshconfig.txt
echo "tk.config.vibcall 100" >> /storage/emulated/0/TKManagerV4/seshconfig.txt
echo " " >> /storage/emulated/0/TKManagerV4/seshconfig.txt
echo "# Disable fsync for increased memory speed at the risk of data loss:" >> /storage/emulated/0/TKManagerV4/seshconfig.txt
echo "# Y - Enabled (Default)" >> /storage/emulated/0/TKManagerV4/seshconfig.txt
echo "# N - Disabled" >> /storage/emulated/0/TKManagerV4/seshconfig.txt
echo " " >> /storage/emulated/0/TKManagerV4/seshconfig.txt
echo "tk.config.Fsync Y" >> /storage/emulated/0/TKManagerV4/seshconfig.txt
echo " " >> /storage/emulated/0/TKManagerV4/seshconfig.txt
echo "# Toggle SELinux:" >> /storage/emulated/0/TKManagerV4/seshconfig.txt
echo "# SELinux permissive is needed to use some audio mods." >> /storage/emulated/0/TKManagerV4/seshconfig.txt
echo "# 0 - Unset (Default)" >> /storage/emulated/0/TKManagerV4/seshconfig.txt
echo "# 1 - Permissive" >> /storage/emulated/0/TKManagerV4/seshconfig.txt
echo "# 2 - Enforcing" >> /storage/emulated/0/TKManagerV4/seshconfig.txt
echo " " >> /storage/emulated/0/TKManagerV4/seshconfig.txt
echo "tk.config.selinux 0" >> /storage/emulated/0/TKManagerV4/seshconfig.txt
echo " " >> /storage/emulated/0/TKManagerV4/seshconfig.txt
echo "# Toggle kernel logging:" >> /storage/emulated/0/TKManagerV4/seshconfig.txt
echo "# 1 - Enabled (Default)" >> /storage/emulated/0/TKManagerV4/seshconfig.txt
echo "# 0 - Disabled" >> /storage/emulated/0/TKManagerV4/seshconfig.txt
echo " " >> /storage/emulated/0/TKManagerV4/seshconfig.txt
echo "tk.config.debug 1" >> /storage/emulated/0/TKManagerV4/seshconfig.txt
echo " " >> /storage/emulated/0/TKManagerV4/seshconfig.txt
echo "# Charging thermals: (Doesn't need reboot)" >> /storage/emulated/0/TKManagerV4/seshconfig.txt
echo "# 0 - Disabled (Disable charging throttle)" >> /storage/emulated/0/TKManagerV4/seshconfig.txt
echo "# 1 - Default (Don't mess with thermals)" >> /storage/emulated/0/TKManagerV4/seshconfig.txt
echo " " >> /storage/emulated/0/TKManagerV4/seshconfig.txt
echo "tk.config.ctherm 1" >> /storage/emulated/0/TKManagerV4/seshconfig.txt
echo " " >> /storage/emulated/0/TKManagerV4/seshconfig.txt
echo "# Delete this file and reboot to restore default settings." >> /storage/emulated/0/TKManagerV4/seshconfig.txt
echo "$dt seshconfig.txt created" > /storage/emulated/0/TKManagerV4/log.txt
setBalancedConfig &
setprop persist.spectrum.profile 0
dt=`date '+%d/%m/%Y %H:%M:%S'`
echo "$dt Balanced profile applied" >> /storage/emulated/0/TKManagerV4/log.txt
else
empty="$(getprop tk.config.empty)"
cprof=$(grep "tk.config.prof" "$config" | cut -d '=' -f2)
cprof=$(echo "$cprof" | awk -v FPAT="[0-9]+" '{print $NF}')
cvibnotif=$(grep "tk.config.vibnotif" "$config" | cut -d '=' -f2)
cvibnotif=$(echo "$cvibnotif" | awk -v FPAT="[0-9]+" '{print $NF}')
let "newvibnotif=cvibnotif*34"
cvibcall=$(grep "tk.config.vibcall" "$config" | cut -d '=' -f2)
cvibcall=$(echo "$cvibcall" | awk -v FPAT="[0-9]+" '{print $NF}')
let "newvibcall=cvibcall*34"
cfsync=$(grep "tk.config.Fsync" "$config" | cut -d '=' -f2)
cfsync=$(echo "$cfsync" | awk -v FPAT="[0-9]+" '{print $NF}')
cselinux=$(grep "tk.config.selinux" "$config" | cut -d '=' -f2)
cselinux=$(echo "$cselinux" | awk -v FPAT="[0-9]+" '{print $NF}')
cdebug=$(grep "tk.config.debug" "$config" | cut -d '=' -f2)
cdebug=$(echo "$cdebug" | awk -v FPAT="[0-9]+" '{print $NF}')
cctherm=$(grep "tk.config.ctherm" "$config" | cut -d '=' -f2)
cctherm=$(echo "$cctherm" | awk -v FPAT="[0-9]+" '{print $NF}')
if [ "$cprof" == 1 ]; then
setPerformanceConfig &
dt=`date '+%d/%m/%Y %H:%M:%S'`
echo "$dt Performance profile selected" >> /storage/emulated/0/TKManagerV4/log.txt
elif [ "$cprof" == 2 ]; then
setBatteryConfig &
dt=`date '+%d/%m/%Y %H:%M:%S'`
echo "$dt Battery profile selected" >> /storage/emulated/0/TKManagerV4/log.txt
elif [ "$cprof" == 3 ]; then 
setGamingConfig &
dt=`date '+%d/%m/%Y %H:%M:%S'`
echo "$dt Gaming profile selected" >> /storage/emulated/0/TKManagerV4/log.txt
else 
setBalancedConfig &
echo "0" > /storage/emulated/0/TKManagerV4/dev/profile.txt
dt=`date '+%d/%m/%Y %H:%M:%S'`
echo "$dt Balanced profile selected" >> /storage/emulated/0/TKManagerV4/log.txt
fi
if [ "$cvibnotif" -ge 0 ] && [ "$cvibnotif" -le 99 ];
then
echo "$newvibnotif" > /sys/class/leds/vibrator/vmax_mv_strong
echo "1" > /sys/class/leds/vibrator/vmax_override
dt=`date '+%d/%m/%Y %H:%M:%S'`
echo "$dt Notification vibration strength $cvibnotif% applied" >> /storage/emulated/0/TKManagerV4/log.txt
else
echo "1" > /sys/class/leds/vibrator/vmax_override
echo "3596" > /sys/class/leds/vibrator/vmax_mv_strong
dt=`date '+%d/%m/%Y %H:%M:%S'`
echo "$dt Notification vibration strength set to 100%" >> /storage/emulated/0/TKManagerV4/log.txt
fi
if [ "$cvibcall" -ge 0 ] && [ "$cvibcall" -le 99 ]; then
echo "$newvibcall" > /sys/class/leds/vibrator/vmax_mv_call
echo "1" > /sys/class/leds/vibrator/vmax_override
dt=`date '+%d/%m/%Y %H:%M:%S'`
echo "$dt Call vibration strength $cvibcall% applied" >> /storage/emulated/0/TKManagerV4/log.txt
else
echo "1" > /sys/class/leds/vibrator/vmax_override
echo "3596" > /sys/class/leds/vibrator/vmax_mv_call
dt=`date '+%d/%m/%Y %H:%M:%S'`
echo "$dt Call vibration strength set to 100%" >> /storage/emulated/0/TKManagerV4/log.txt
fi
if [ "$cfsync" == N ];
then
echo "1" > /sys/kernel/dyn_fsync/Dyn_fsync_active
dt=`date '+%d/%m/%Y %H:%M:%S'`
echo "$dt Fsync will be disabled when screens on" >> /storage/emulated/0/TKManagerV4/log.txt
else
echo "0" > /sys/kernel/dyn_fsync/Dyn_fsync_active
dt=`date '+%d/%m/%Y %H:%M:%S'`
echo "$dt Fsync will stay enabled" >> /storage/emulated/0/TKManagerV4/log.txt
fi
if [ "$cselinux" == 1 ];
then
setenforce 0
dt=`date '+%d/%m/%Y %H:%M:%S'`
echo "$dt SELinux set to permissive" >> /storage/emulated/0/TKManagerV4/log.txt
elif [ "$cselinux" == 2 ]; then 
setenforce 1
dt=`date '+%d/%m/%Y %H:%M:%S'`
echo "$dt SELinux set to enforcing" >> /storage/emulated/0/TKManagerV4/log.txt
else
echo "$dt SELinux unset" >> /storage/emulated/0/TKManagerV4/log.txt
fi
if [ "$cdebug" == 0 ];
then
setprop profiler.force_disable_err_rpt 1
setprop profiler.force_disable_ulog 1
setprop logcat.live disable
setprop ro.kernel.android.checkjni 0
setprop ro.kernel.checkjni 0
setprop ro.config.nocheckin 1
setprop debugtool.anrhistory 0
setprop profiler.debugmonitor false
setprop profiler.hung.dumpdobugreport false
echo "0" > /proc/sys/debug/exception-trace
echo "0 0 0 0" > /proc/sys/kernel/printk
dt=`date '+%d/%m/%Y %H:%M:%S'`
echo "$dt Kernel logging disabled" >> /storage/emulated/0/TKManagerV4/log.txt
else
dt=`date '+%d/%m/%Y %H:%M:%S'`
echo "$dt Kernel logging enabled" >> /storage/emulated/0/TKManagerV4/log.txt
fi
if [ "$cctherm" == 0 ];
then
echo "Y" > /sys/module/smb_lib/parameters/skip_thermal
dt=`date '+%d/%m/%Y %H:%M:%S'`
echo "$dt Charging throttle disabled" >> /storage/emulated/0/TKManagerV4/log.txt
else
echo "N" > /sys/module/smb_lib/parameters/skip_thermal
dt=`date '+%d/%m/%Y %H:%M:%S'`
echo "$dt Charging throttle enabled" >> /storage/emulated/0/TKManagerV4/log.txt
fi
fi
if [ "$cvibnotif" == 100 ] && [ "$cvibcall" == 100 ]; 
then
echo "0" > /sys/class/leds/vibrator/vmax_override
fi
if [ ! -f /storage/emulated/0/TKManagerV4/seshconfig.txt ]; then
echo "0" > /sys/class/leds/vibrator/vmax_override
fi
if ! [ "$cvibnotif" -ge 0 -a "$cvibnotif" -le 100 ]; then 
echo "0" > /sys/class/leds/vibrator/vmax_override
fi
if ! [ "$cvibcall" -ge 0 -a "$cvibcall" -le 100 ]; then 
echo "0" > /sys/class/leds/vibrator/vmax_override
fi
if [ "$cvibnotif" == "$empty" ] 
then
echo "0" > /sys/class/leds/vibrator/vmax_override
echo "3596" > /sys/class/leds/vibrator/vmax_mv_strong
fi
if [ "$cvibcall" == "$empty" ]; 
then
echo "0" > /sys/class/leds/vibrator/vmax_override
echo "3596" > /sys/class/leds/vibrator/vmax_mv_call
fi
trim
sleep 10
InitEngine &
fi
