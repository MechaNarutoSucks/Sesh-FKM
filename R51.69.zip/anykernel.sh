# AnyKernel3 Ramdisk Mod Script
# osm0sis @ xda-developers
# Used by me @ xda-developers

## AnyKernel setup
# begin properties
properties() { '
kernel.string=seshstation by D1stRU3T0R
do.devicecheck=0
do.modules=0
do.cleanup=1
do.cleanuponabort=1
device.name1=beryllium
device.name2=
device.name3=
device.name4=
device.name5=
supported.versions=
supported.patchlevels=
'; } # end properties

# shell variables
block=/dev/block/bootdevice/by-name/boot;
is_slot_device=0;
ramdisk_compression=auto;

## end install

## AnyKernel methods (DO NOT CHANGE)
# import patching functions/variables - see for reference
. tools/ak3-core.sh;

# Set Android version for kernel
ver="$(file_getprop /system/build.prop ro.build.version.release)"
if [ ! -z "$ver" ]; then
  patch_cmdline "androidboot.version" "androidboot.version=$ver"
else
  patch_cmdline "androidboot.version" ""
fi

## AnyKernel install
dump_boot;
if [ -d /data/adb/magisk ]; then
mkdir -p /data/adb/modules
cp -R /tmp/anykernel/tools/twistedkernel /data/adb/modules
else
ui_print "Magisk not installed."
fi
ui_print "Installing seshstation..."
ui_print "Your Gaming Phone is ready! Join our telegram group for more news!"
write_boot;
